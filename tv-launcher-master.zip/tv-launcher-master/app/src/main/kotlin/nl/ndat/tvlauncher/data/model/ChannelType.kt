package nl.ndat.tvlauncher.data.model

enum class ChannelType {
	PREVIEW,
	WATCH_NEXT,
}
