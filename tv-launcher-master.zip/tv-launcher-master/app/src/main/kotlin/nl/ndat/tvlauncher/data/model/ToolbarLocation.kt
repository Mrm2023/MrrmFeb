package nl.ndat.tvlauncher.data.model

enum class ToolbarLocation {
	START, CENTER, END
}
