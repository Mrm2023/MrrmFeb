package nl.ndat.tvlauncher.data.model

enum class InputType {
	TUNER,
	OTHER,
	COMPOSITE,
	SVIDEO,
	SCART,
	COMPONENT,
	VGA,
	DVI,
	HDMI,
	DISPLAY_PORT,
}
